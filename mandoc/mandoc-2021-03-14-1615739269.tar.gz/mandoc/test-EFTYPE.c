#include <errno.h>

int
main(void)
{
	return !EFTYPE;
}
